a = int(input("Enter a "))
E=0
for N in range(0, a, 1):
    E = E + N
print(E)