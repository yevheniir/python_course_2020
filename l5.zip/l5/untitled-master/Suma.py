a = int(input("Enter a "))
E=0
N=1
while N<=a:
    E=E+N
    N=N+1
print(E)